from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import pandas as pd
from dotenv import load_dotenv
import google.generativeai as genai
from google.generativeai import protos

# Carga de variables de entorno
env_path = os.path.join(os.path.dirname(__file__), '.env')
load_dotenv(env_path)
API_KEY = "AIzaSyAqzQbReUQu3OJOWZwulhqzyEcZrq7w_Z8"
MODEL_ID = os.getenv("GEMINI_MODEL_ID", "gemini-2.0-flash")
if not API_KEY:
    raise RuntimeError("Define GENAI_API_KEY en tu .env")

# Configura el modelo
genai.configure(api_key=API_KEY)
model = genai.GenerativeModel(MODEL_ID)

# Cargar datos de estudiantes
df = pd.read_excel("resultados_acompanamiento_final.xlsx", engine="openpyxl")

# Selecciona automáticamente el estudiante con ID = 1
student_row = df.loc[df["ID"] == 1]
if student_row.empty:
    raise RuntimeError("No se encontró estudiante con ID=1")

student = student_row.iloc[0]
name = student.get("STUDENT_NAME", "Estudiante 1")
follow_up = student.get("FOLLOW_UP", "")

# Inicia la sesión del chat
init_text = (
    "Eres un tutor universitario experto en orientación estudiantil. "
    f"Este es tu plan de acompañamiento personalizado, {name}: {follow_up}"
)
initial_content = protos.Content(role="user", parts=[protos.Part(text=init_text)])
chat = model.start_chat(history=[initial_content])

# Servidor Flask
app = Flask(__name__, static_folder='.', static_url_path='')
CORS(app)

@app.route('/')
def root():
    return send_from_directory('.', 'views/chatbot.html')

@app.route("/chat", methods=["POST"])
def chat_endpoint():
    data = request.get_json() or {}
    message = data.get("message", "").strip()
    if not message:
        return jsonify(success=False, error="Falta el 'message'"), 400

    resp = chat.send_message(message)
    return jsonify(success=True, response=resp.text.strip())

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
