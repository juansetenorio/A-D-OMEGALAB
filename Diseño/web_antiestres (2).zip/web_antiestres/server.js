import express from 'express';
import cors from 'cors';
import fetch from 'node-fetch';

const app = express();
app.use(cors());
app.use(express.json());

// Ruta para manejar los mensajes del chat
app.post('/chat', async (req, res) => {
    try {
        console.log('Received chat request:', req.body);  // Debug log

        const response = await fetch('http://localhost:5000/chat-message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(req.body)
        });

        const data = await response.json();
        console.log('Response from Python:', data);  // Debug log
        res.json(data);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});