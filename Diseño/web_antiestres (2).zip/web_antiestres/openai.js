const { Configuration, OpenAIApi } = require("openai");

// Configuración de la API con tu clave
const configuration = new Configuration({
  apiKey: "TU_CLAVE_API_AQUÍ", // Reemplaza con tu clave de OpenAI
});
const openai = new OpenAIApi(configuration);

async function generarRecomendacion(nivelDeEstres) {
  try {
    const prompt = `El nivel de estrés del estudiante es ${nivelDeEstres}. Proporciona recomendaciones personalizadas para ayudarlo.`;
    const response = await openai.createCompletion({
      model: "text-davinci-003", // Modelo GPT-4 o Davinci
      prompt: prompt,
      max_tokens: 100, // Longitud de la respuesta
      temperature: 0.7, // Controla la creatividad
    });

    // Devuelve la recomendación generada
    return response.data.choices[0].text.trim();
  } catch (error) {
    console.error("Error al generar recomendación:", error);
    return "No se pudo generar una recomendación.";
  }
}

module.exports = { generarRecomendacion };