// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDQnNJMixoSF9LKuyp0yGVEmAVuelU9O9U",
  authDomain: "pila-187a6.firebaseapp.com",
  projectId: "pila-187a6",
  storageBucket: "pila-187a6.firebasestorage.app",
  messagingSenderId: "681830547064",
  appId: "1:681830547064:web:dda817897e98d5947cf78d"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);