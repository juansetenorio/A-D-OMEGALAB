// Importar Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.21.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.21.0/firebase-auth.js";

// Configuración de Firebase
const firebaseConfig = {
    apiKey: "AIzaSyDQnNJMixoSF9LKuyp0yGVEmAVuelU9O9U",
    authDomain: "pila-187a6.firebaseapp.com",
    projectId: "pila-187a6",
    storageBucket: "pila-187a6.appspot.com",
    messagingSenderId: "681830547064",
    appId: "1:681830547064:web:dda817897e98d5947cf78d"
};

// Inicialización de Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Función para inicializar elementos UI
function initializeUI() {
    // Inicializar menú
    const menuToggle = document.getElementById('menu-toggle');
    const mobileNav = document.getElementById('mobile-nav');
    const menuOverlay = document.getElementById('menu-overlay');

    if (menuToggle && mobileNav && menuOverlay) {
        initializeMenu(menuToggle, mobileNav, menuOverlay);
    }

    // Inicializar chatbot
    const chatButton = document.getElementById('send-chat');
    const chatInput = document.getElementById('chat-input');
    
    if (chatButton && chatInput) {
        initializeChatbot(chatButton, chatInput);
    }

    // Inicializar transiciones de página
    initializePageTransitions();

    // Actualizar fecha y usuario
    updateCurrentInfo();
}

// Funciones de autenticación
function initializeAuth() {
    // Registro de usuario
    const registerButton = document.getElementById("register-button");
    if (registerButton) {
        registerButton.addEventListener("click", () => {
            const email = document.getElementById("register-email").value;
            const password = document.getElementById("register-password").value;
            createUserWithEmailAndPassword(auth, email, password)
                .then(() => alert("Usuario registrado con éxito"))
                .catch(error => alert(error.message));
        });
    }

    // Inicio de sesión
    const loginButton = document.getElementById("login-button");
    if (loginButton) {
        loginButton.addEventListener("click", () => {
            const email = document.getElementById("login-email").value;
            const password = document.getElementById("login-password").value;
            signInWithEmailAndPassword(auth, email, password)
                .then(userCredential => {
                    const userEmail = userCredential.user.email;
                    window.location.href = userEmail === "admin@example.com" 
                        ? "views/admin.html" 
                        : "views/student.html";
                })
                .catch(error => alert(error.message));
        });
    }

    // Cierre de sesión
    const logoutButton = document.getElementById("logout-button");
    if (logoutButton) {
        logoutButton.addEventListener("click", (e) => {
            e.preventDefault();
            signOut(auth).then(() => {
                window.location.href = "../index.html";
            });
        });
    }
}

// Funciones del menú
function initializeMenu(menuToggle, mobileNav, menuOverlay) {
    function closeMenu() {
        menuToggle.classList.remove('active');
        mobileNav.classList.remove('active');
        menuOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    function toggleMenu() {
        menuToggle.classList.toggle('active');
        mobileNav.classList.toggle('active');
        menuOverlay.classList.toggle('active');
        document.body.style.overflow = mobileNav.classList.contains('active') ? 'hidden' : '';
    }

    menuToggle.addEventListener('click', toggleMenu);
    menuOverlay.addEventListener('click', closeMenu);

    // Cerrar menú al hacer clic en enlaces
    document.querySelectorAll('.navbar nav.mobile a').forEach(link => {
        link.addEventListener('click', closeMenu);
    });

    // Cerrar menú al redimensionar
    window.addEventListener('resize', () => {
        if (window.innerWidth > 768) {
            closeMenu();
        }
    });
}

// Funciones del chatbot (versión optimizada)
function initializeChatbot(chatButton, chatInput) {
    // Deshabilitar botón por defecto
    chatButton.style.pointerEvents = 'none';
    chatButton.style.opacity = '0.5';

    // Manejar cambios en el input
    chatInput.addEventListener('input', () => {
        const isInputEmpty = chatInput.value.trim() === '';
        chatButton.style.pointerEvents = isInputEmpty ? 'none' : 'auto';
        chatButton.style.opacity = isInputEmpty ? '0.5' : '1';
    });

    // Manejar clic en el botón
    chatButton.addEventListener('click', (e) => {
        e.preventDefault();
        const mensaje = chatInput.value.trim();
        if (mensaje) {
            // Guardar mensaje tanto en localStorage como en sessionStorage
            localStorage.setItem('chatMessage', mensaje);
            sessionStorage.setItem('ultimoMensaje', mensaje);
            // Redirigir a la página del chat
            window.location.href = 'chat.html';
        }
    });

    // Manejar tecla Enter
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && chatInput.value.trim()) {
            chatButton.click();
        }
    });
}

// Funciones de transición de página
function initializePageTransitions() {
    document.querySelectorAll("a").forEach(link => {
        link.addEventListener("click", event => {
            const href = link.getAttribute("href");
            if (href && !href.startsWith("#") && !link.hasAttribute("data-no-transition")) {
                event.preventDefault();
                document.body.classList.add("page-transition");
                setTimeout(() => {
                    window.location.href = href;
                }, 500);
            }
        });
    });
}

// Función para actualizar fecha y usuario
function updateCurrentInfo() {
    const currentDate = document.getElementById('current-date');
    const currentUser = document.getElementById('current-user');
    
    if (currentDate && currentUser) {
        setInterval(() => {
            const now = new Date();
            currentDate.textContent = now.toISOString().slice(0, 19).replace('T', ' ');
            currentUser.textContent = 'Usuario: 1cfer';
        }, 1000);
    }
}

// Inicializar todo cuando el DOM esté listo
document.addEventListener("DOMContentLoaded", () => {
    initializeAuth();
    initializeUI();
});

// Verificar estado de autenticación
onAuthStateChanged(auth, user => {
    if (user) {
        console.log("Usuario autenticado:", user.email);
    } else {
        console.log("No hay usuario autenticado.");
    }
});