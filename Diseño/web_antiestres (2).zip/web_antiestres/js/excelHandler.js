class ExcelHandler {
    constructor() {
        this.XLSX = XLSX;
        this.filePath = 'data/estudiantes.xlsx';
    }

    // Leer todo el archivo Excel
    async readExcelFile() {
        try {
            const response = await fetch(this.filePath);
            const arrayBuffer = await response.arrayBuffer();
            const data = new Uint8Array(arrayBuffer);
            const workbook = XLSX.read(data, { type: 'array' });
            
            // Obtener la primera hoja
            const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
            
            // Convertir a JSON
            return XLSX.utils.sheet_to_json(firstSheet);
        } catch (error) {
            console.error('Error al leer el archivo Excel:', error);
            throw error;
        }
    }

    // Buscar estudiante por correo
    async findStudentByEmail(email) {
        try {
            const data = await this.readExcelFile();
            return data.find(student => student.Correo === email);
        } catch (error) {
            console.error('Error al buscar estudiante:', error);
            throw error;
        }
    }

    // Obtener todos los estudiantes
    async getAllStudents() {
        try {
            return await this.readExcelFile();
        } catch (error) {
            console.error('Error al obtener estudiantes:', error);
            throw error;
        }
    }
}