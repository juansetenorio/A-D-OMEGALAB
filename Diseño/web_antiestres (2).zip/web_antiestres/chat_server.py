from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import google.generativeai as genai
from datetime import datetime

app = Flask(__name__)
CORS(app)  # Esto permite las solicitudes desde el frontend

# Configuración de Gemini
def init_model():
    api_key = "AIzaSyAqzQbReUQu3OJOWZwulhqzyEcZrq7w_Z8"
    model_id = "gemini-2.0-flash"
    genai.configure(api_key=api_key)
    return genai.GenerativeModel(model_id)

# Variables globales
model = init_model()
chats = {}  # Almacena las sesiones de chat por correo

def load_student_data(email):
    """Carga los datos del estudiante desde el Excel usando el correo institucional"""
    try:
        df = pd.read_excel("resultados_acompanamiento_final.xlsx")
        student = df[df['INSTITUTIONAL_EMAIL'] == email].iloc[0]
        return {
            'name': student['STUDENT_NAME'],
            'stress_level': student['STRESS_LEVEL'],
            'follow_up': student.get('FOLLOW_UP', '')
        }
    except Exception as e:
        print(f"Error loading student data: {e}")
        return None

@app.route('/chat-message', methods=['POST'])
def chat_message():
    data = request.json
    email = data.get('correo')
    message = data.get('message')
    
    print(f"Received message from {email}: {message}")  # Debug log

    if not email or not message:
        return jsonify({
            "success": False,
            "error": "Email and message are required"
        }), 400

    try:
        # Si no existe una sesión de chat para este correo, la creamos
        if email not in chats:
            student_data = load_student_data(email)
            if not student_data:
                return jsonify({
                    "success": False,
                    "error": "Student not found"
                }), 404

            # Inicializar el chat con el contexto del estudiante
            init_text = (
                f"Eres un tutor universitario experto en orientación estudiantil. "
                f"Este es tu plan de acompañamiento personalizado para {student_data['name']}, "
                f"quien tiene un nivel de estrés de {student_data['stress_level']}: "
                f"{student_data['follow_up']}"
            )
            
            chat = model.start_chat(history=[{"role": "user", "parts": [init_text]}])
            chats[email] = {
                'chat': chat,
                'student_data': student_data
            }
            print(f"Created new chat session for {email}")  # Debug log

        # Enviar mensaje y obtener respuesta
        chat_session = chats[email]['chat']
        response = chat_session.send_message(message)
        bot_response = response.text

        print(f"Bot response for {email}: {bot_response}")  # Debug log

        return jsonify({
            "success": True,
            "response": bot_response
        })

    except Exception as e:
        print(f"Error in chat: {str(e)}")  # Debug log
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

if __name__ == '__main__':
    app.run(port=5000, debug=True)